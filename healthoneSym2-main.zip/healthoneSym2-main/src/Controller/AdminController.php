<?php


namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class AdminController extends AbstractController
{
    /**
     * @Route("/",name="Homepage")
     */
    public function homepageAction(){
        return $this->render("homepage.html.twig");
    }
}