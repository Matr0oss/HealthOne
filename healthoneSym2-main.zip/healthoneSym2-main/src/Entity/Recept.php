<?php

namespace App\Entity;

use App\Repository\ReceptRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ReceptRepository::class)
 */
class Recept
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $recept;

    /**
     * @ORM\ManyToOne(targetEntity=Medicijn::class, inversedBy="recepts")
     */
    private $Medicijnen;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getRecept(): ?string
    {
        return $this->recept;
    }

    public function setRecept(string $recept): self
    {
        $this->recept = $recept;

        return $this;
    }

    public function getMedicijnen(): ?Medicijn
    {
        return $this->Medicijnen;
    }

    public function setMedicijnen(?Medicijn $Medicijnen): self
    {
        $this->Medicijnen = $Medicijnen;

        return $this;
    }

}
